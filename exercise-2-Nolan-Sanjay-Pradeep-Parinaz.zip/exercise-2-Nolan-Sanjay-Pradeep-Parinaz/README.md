-- Provide Instructions on how to run the code --

1. Start a terminal
2. Change the working location of the terminal to the current directory (directory containing README.md)
3. Start a python server by typying "python -m http.server 8888"
4. Open the following URL in a browser (http://localhost:8888)

* Note that the instruction may vary depending on OS being used. The above instructions to start python web server have been tested on Windows 10 with Python 3.6 (Anaconda)